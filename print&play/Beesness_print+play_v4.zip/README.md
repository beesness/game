# Contents

You'll need to print roughly:

* 6 copies of `cards.pdf`
* 1 copy of `props.pdf`
* 2 copies of `honey.pdf`
* 1 copy of the rulebook

After you play it, please get in touch and let me know what you think **matteo@beesness.games**

Enjoy :)


## License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-nc-sa/4.0)

[![](http://mirrors.creativecommons.org/presskit/buttons/88x31/svg/by-nc-sa.svg)](http://creativecommons.org/licenses/by-nc-sa/4.0)